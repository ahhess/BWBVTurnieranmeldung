<?php /* Smarty version 2.5.0, created on 2003-08-27 22:02:37
         compiled from footer.tpl */ ?>
</BODY>
</HTML>