<?php /* Smarty version 2.5.0, created on 2003-08-27 22:02:37
         compiled from header.tpl */ ?>
<?php $this->_load_plugins(array(
array('function', 'popup_init', 'header.tpl', 3, false),)); ?><HTML>
<HEAD>
<?php echo $this->_plugins['function']['popup_init'][0](array('src' => "/javascripts/overlib.js"), $this) ; ?>

<TITLE><?php echo $this->_tpl_vars['title']; ?>
 - <?php echo $this->_tpl_vars['Name']; ?>
</TITLE>
</HEAD>
<BODY bgcolor="#ffffff">