<?php $_config_vars = array (
  'title' => 'Welcome to Smarty!',
  'cutoff_size' => '40',
  'bold' => true,
); return true; ?>