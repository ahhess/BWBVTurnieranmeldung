<!doctype html public "-//W3C//DTD HTML 4.0 //EN">
<html>
<head>
       <title>Title here!</title>
</head>
<body>
<?php
echo "pear erfolgreich getestet";
?>
</body>
</html>
