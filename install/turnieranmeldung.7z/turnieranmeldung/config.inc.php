<?php

/*
$host="localhost";
$user="root";
$password="";
$database="anmeldung";
*/
$host="localhost";
$user="";
$password="";
$database="";

?>
